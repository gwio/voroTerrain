![Voronoi Diagram](http://farm8.staticflickr.com/7193/6967101789_519a469cd0_b.jpg)

Simple addon to make voronoi diagrams in openFrameworks. 

The algorithm is a modified version of Stephan Fortune's sweep line algorithm
http://ect.bell-labs.com/who/sjf/

Orignal Code from Shane O'Sullivan
http://www.skynet.ie/~sos/mapviewer/voronoi.php
